package pkg;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.*;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/capgemini")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public MyServlet() {
        System.out.println("serlvet object created ");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
    	
    	System.out.println("within service method ");
    	doPost(request,response);
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("within do get ");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("within do post ");
		//how to read the value entered in the text field ?
		
		/*String name = request.getParameter("mynm");//name given to the html textfield
		System.out.println(name);
		String name1 = request.getParameter("name");//null
		
		System.out.println(name1.length());//ans ?? null pointer exceptin 
*/		
		/*
		 * in the projects; the html is designed by one person adn the servlet is wirtten by another person 
		 * 
		 * u do not know the html form element names; in this case u will use hte following code 
		 * 
		 */
		Enumeration enu = request.getParameterNames();	
		
		while(enu.hasMoreElements()){
			
			String parameterName = (String)enu.nextElement();
			String parameterValue = request.getParameter(parameterName)	;
			
			System.out.println(parameterName + " = " +  parameterValue);
		}
		
	}
	
	public void myMethod(){
		
		System.out.println("my method ");
	}

}
